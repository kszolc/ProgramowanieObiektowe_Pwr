#include "Rectangle.hh"


/*
 *  Tutaj nalezy zdefiniowac odpowiednie metody
 *  klasy Rectangle, ktore zawieraja 
 *  wiecej kodu niz dwie linijki.
 *  Mniejsze metody mozna definiwac w ciele klasy.
 */
