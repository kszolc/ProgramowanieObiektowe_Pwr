#include "Vector2D.hh"


/*
 *  Tutaj nalezy zdefiniowac odpowiednie metody
 *  klasy Vector2D, ktore zawieraja wiecej kodu
 *  niz dwie linijki.
 *  Mniejsze metody mozna definiwac w ciele klasy.
 */
