#include "Matrix2x2.hh"


/*
 *  Tutaj nalezy zdefiniowac odpowiednie metody
 *  klasy Matrix2x2, ktore zawieraja wiecej kodu
 *  niz dwie linijki.
 *  Mniejsze metody mozna definiwac w ciele klasy.
 */
